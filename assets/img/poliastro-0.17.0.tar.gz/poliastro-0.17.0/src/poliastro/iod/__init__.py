# Select default algorithm
from poliastro.iod.izzo import lambert

__all__ = ["lambert"]
