"""
Mathematical utilities not stricly related to Astrodynamics.
Mostly wrappers around SciPy.
"""
